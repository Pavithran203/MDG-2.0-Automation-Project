import { type Page, type Locator } from '@playwright/test';

/**
 * Page Object for Material Search (/app/request/material-search) — scenario 5.
 *
 * Structure (discovery, UI in Portuguese):
 *   - A textarea for one or more material numbers (placeholder "ex.: 100000123 ...").
 *   - Additional filter inputs (description, manufacturer, part) + type/plant/status selects.
 *   - "Pesquisar" (Search), "Redefinir" (Reset), "Exportar como CSV" buttons.
 *   - Results table with columns incl. "Número do Material" and an "Ações" column.
 */
export class MaterialSearchPage {
  constructor(readonly page: Page) {}

  async goto(): Promise<void> {
    await this.page.goto('/app/request/material-search', { waitUntil: 'networkidle', timeout: 30_000 }).catch(async () => {
      await this.page.goto('/app/request/material-search', { waitUntil: 'domcontentloaded', timeout: 30_000 });
    });
    await this.page.waitForTimeout(800);
  }

  materialNumberInput(): Locator {
    return this.page.locator('textarea[placeholder*="100000123" i], textarea').first();
  }

  searchButton(): Locator {
    return this.page.getByRole('button', { name: /^Pesquisar$|^Search$/i }).first();
  }

  resetButton(): Locator {
    return this.page.getByRole('button', { name: /Redefinir|Reset|Limpar/i }).first();
  }

  table(): Locator {
    return this.page.locator('table').first();
  }

  rows(): Locator {
    return this.table().locator('tbody tr');
  }

  async rowCount(): Promise<number> {
    return this.rows().count().catch(() => 0);
  }

  /** Enter a material number and run the search. */
  async searchByNumber(materialNo: string): Promise<void> {
    await this.materialNumberInput().fill(materialNo);
    await this.searchButton().click();
    await this.page.waitForTimeout(1500);
  }

  /** Run search with no filters -> should list all material data. */
  async searchAll(): Promise<void> {
    await this.resetButton().click().catch(() => {});
    await this.page.waitForTimeout(400);
    await this.searchButton().click();
    await this.page.waitForTimeout(1500);
  }

  /** Grab the material number from the first result row (for a valid-search test). */
  async firstMaterialNumber(): Promise<string> {
    const cell = this.rows().first().locator('td').first();
    return (await cell.innerText().catch(() => '')).trim();
  }

  /**
   * The "view details" action button in a row — titled "Ver Detalhe do Material"
   * (PT) or "View Material Detail" (EN). Not the vendor-collaboration button.
   */
  rowAction(row: Locator): Locator {
    return row
      .locator('button[title*="Detalhe" i], button[title*="Detail" i], button.ab-view')
      .first();
  }
}
