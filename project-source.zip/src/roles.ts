/**
 * Central definition of every user role and its credentials.
 * Credentials are read from environment variables (see .env / .env.example).
 */

export type RoleName =
  | 'initiator'
  | 'validator'
  | 'reviewer'
  | 'cataloguer'
  | 'qc';

export interface RoleCredentials {
  role: RoleName;
  /** Human-friendly label for reports */
  label: string;
  username: string;
  password: string;
}

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `Missing environment variable "${name}". ` +
        `Copy .env.example to .env and fill in the credentials.`,
    );
  }
  return value;
}

export const ROLES: Record<RoleName, RoleCredentials> = {
  initiator: {
    role: 'initiator',
    label: 'Initiator',
    username: required('INITIATOR_USERNAME'),
    password: required('INITIATOR_PASSWORD'),
  },
  validator: {
    role: 'validator',
    label: 'Validator',
    username: required('VALIDATOR_USERNAME'),
    password: required('VALIDATOR_PASSWORD'),
  },
  reviewer: {
    role: 'reviewer',
    label: 'Reviewer',
    username: required('REVIEWER_USERNAME'),
    password: required('REVIEWER_PASSWORD'),
  },
  cataloguer: {
    role: 'cataloguer',
    label: 'Cataloguer',
    username: required('CATALOGUER_USERNAME'),
    password: required('CATALOGUER_PASSWORD'),
  },
  qc: {
    role: 'qc',
    label: 'QC',
    username: required('QC_USERNAME'),
    password: required('QC_PASSWORD'),
  },
};

export const ALL_ROLES: RoleCredentials[] = Object.values(ROLES);
