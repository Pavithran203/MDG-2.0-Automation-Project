import { test, expect, type Page } from '@playwright/test';
import { ROLES } from './roles.js';
import { LoginPage } from './LoginPage.js';
import { LibraryPage } from './LibraryPage.js';
import { ResultsReporter, type TestCaseResult } from './resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

export interface LibScenario {
  /** Results folder name, e.g. "scenario-07". */
  scenario: string;
  /** Report title, e.g. "Scenario 7 — Noun Modifier Library". */
  title: string;
  /** Page URL under /app. */
  url: string;
  /** Test-case id prefix, e.g. "TC-S7". */
  idPrefix: string;
}

/**
 * Registers the standard read-only library-page test suite (search valid /
 * invalid, download, read-only) for one scenario. Shared by scenarios 7-10.
 */
export function registerLibraryScenario(lib: LibScenario): void {
  test.describe.serial(lib.title, () => {
    let reporter: ResultsReporter;

    test.beforeAll(() => {
      reporter = new ResultsReporter({ scenario: lib.scenario, title: lib.title, baseUrl: BASE_URL });
      console.log(`\n[results] ${lib.scenario} -> ${reporter.runDir}`);
    });
    test.afterAll(() => {
      console.log(`[results] ${lib.scenario} saved -> ${reporter.finalize()}`);
    });

    test.beforeEach(async ({ page }) => {
      const login = new LoginPage(page);
      await login.login(ROLES.initiator);
      await login.assertLoggedIn(ROLES.initiator);
    });

    async function record(page: Page, rec: Omit<TestCaseResult, 'status'>, body: () => Promise<string>): Promise<void> {
      const started = Date.now();
      const full: TestCaseResult = { status: 'failed', ...rec };
      try {
        full.actual = await body();
        full.status = 'passed';
      } catch (err) {
        full.actual = `Error: ${(err as Error).message}`;
        await page.screenshot({ path: reporter.screenshotPath(rec.id), fullPage: true }).catch(() => {});
        full.status = 'failed';
        throw err;
      } finally {
        full.durationMs = Date.now() - started;
        reporter.add(full);
      }
    }

    test(`${lib.idPrefix}-01 | Search with valid value returns results`, async ({ page }) => {
      const p = new LibraryPage(page, lib.url);
      await p.goto();
      await record(
        page,
        { id: `${lib.idPrefix}-01`, title: 'Search with a valid value returns matching results', expected: 'Rows are returned for an existing value' },
        async () => {
          const initial = await p.rowCount();
          expect(initial, 'page should load with admin data').toBeGreaterThan(0);
          const sample = (await p.firstCellText()).split(/\s+/)[0] || '';
          const searched = await p.search(sample);
          if (!searched) return `No search input available; page shows ${initial} row(s) of admin data.`;
          const after = await p.rowCount();
          expect(after, 'valid search should return at least one row').toBeGreaterThan(0);
          return `Searched "${sample}" -> ${after} row(s) (page loaded with ${initial}).`;
        },
      );
    });

    test(`${lib.idPrefix}-02 | Search with invalid value returns no results`, async ({ page }) => {
      const p = new LibraryPage(page, lib.url);
      await p.goto();
      await record(
        page,
        { id: `${lib.idPrefix}-02`, title: 'Search with an invalid value returns no results', input: 'ZZZ-NO-SUCH-VALUE-9999', expected: 'Empty result set / no rows' },
        async () => {
          const searched = await p.search('ZZZ-NO-SUCH-VALUE-9999');
          if (!searched) return 'No search input available on this page.';
          const after = await p.rowCount();
          const bodyText = (await p.table().innerText().catch(() => '')).toLowerCase();
          const emptyState = /nenhum|no data|sem resultados|não encontrad|vazio|no records/i.test(bodyText);
          expect(after === 0 || emptyState, `invalid search should yield no data (rows=${after})`).toBe(true);
          return `Invalid search -> rows=${after}, emptyState=${emptyState}`;
        },
      );
    });

    test(`${lib.idPrefix}-03 | Download/export produces a file`, async ({ page }) => {
      const p = new LibraryPage(page, lib.url);
      await p.goto();
      await record(
        page,
        { id: `${lib.idPrefix}-03`, title: 'Download/export button produces a file', expected: 'A non-empty file is downloaded' },
        async () => {
          const dl = await p.download();
          expect(dl, 'an export/download should be triggered').not.toBeNull();
          const name = dl!.suggestedFilename();
          const path = await dl!.path();
          const fs = await import('node:fs');
          const size = path ? fs.statSync(path).size : 0;
          expect(size, 'downloaded file should be non-empty').toBeGreaterThan(0);
          return `Downloaded "${name}" (${size} bytes).`;
        },
      );
    });

    test(`${lib.idPrefix}-04 | Page is read-only`, async ({ page }) => {
      const p = new LibraryPage(page, lib.url);
      await p.goto();
      await record(
        page,
        { id: `${lib.idPrefix}-04`, title: 'Page is read-only (no create/edit/delete controls)', expected: 'No mutation controls present' },
        async () => {
          const mutable = await p.hasMutationControls();
          expect(mutable, 'read-only page should not expose edit/delete/create').toBe(false);
          return 'No create/edit/delete controls found — page is read-only.';
        },
      );
    });
  });
}
