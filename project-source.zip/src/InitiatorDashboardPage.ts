import { type Page, type Locator } from '@playwright/test';

/**
 * Page Object for the Initiator Dashboard (/app/initiator/dashboard).
 *
 * Structure confirmed via discovery (UI is in Portuguese):
 *  - 6 count cards: Total de Solicitações, Rascunho, Em Andamento, Devolvido,
 *    Rejeitados, Concluídos.
 *  - A status filter <select> (Todos / Rascunho / Devolvido / Em Andamento /
 *    Rejeitados / Concluídos) and a page-size <select>.
 *  - A toolbar above the table with a search (magnifier) control.
 *  - A "Minhas Solicitações" table. Per row:
 *      a.req-link            -> open request
 *      button.comment-btn    -> opens "Comentários da Solicitação" modal
 *      button.log-btn        -> opens "Registros da Solicitação" modal
 *      button.dash-action-btn[title="Editar"]  -> edit (draft only)
 *      button.dash-action-btn[title="Excluir"] -> delete (draft only)
 */
export class InitiatorDashboardPage {
  constructor(readonly page: Page) {}

  async goto(): Promise<void> {
    await this.page.goto('/app/initiator/dashboard', { waitUntil: 'networkidle' });
    await this.table().first().waitFor({ state: 'visible', timeout: 20_000 }).catch(() => {});
  }

  table(): Locator {
    return this.page.locator('table').first();
  }

  rows(): Locator {
    return this.table().locator('tbody tr');
  }

  /**
   * Read a count card by any of its label aliases. The app can render in
   * English OR Portuguese, so each card is matched against both, e.g.
   * ['Total Requests', 'Total de Solicitações']. Returns the integer or null.
   */
  async getCount(aliases: string[]): Promise<number | null> {
    return this.page.evaluate((labels) => {
      const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const els = Array.from(document.querySelectorAll('div, span, p'));
      for (const el of els) {
        const e = el as HTMLElement;
        if (e.children.length > 4) continue;
        const text = (e.textContent ?? '').replace(/\s+/g, ' ').trim();
        for (const lbl of labels) {
          // Card text looks like "24Draft" / "24 Draft" / "24Rascunho".
          const re = new RegExp(`^(\\d+)\\s*${esc(lbl)}$`, 'i');
          const m = text.match(re);
          if (m) return parseInt(m[1], 10);
        }
      }
      return null;
    }, aliases);
  }

  /**
   * The six status cards, each with English + Portuguese aliases, keyed by a
   * stable English name so callers and reports don't depend on UI language.
   */
  private static readonly COUNT_CARDS: Record<string, string[]> = {
    Total: ['Total Requests', 'Total de Solicitações'],
    Draft: ['Draft', 'Rascunho'],
    'In Progress': ['In Progress', 'Em Andamento'],
    Returned: ['Returned', 'Devolvido'],
    Rejected: ['Rejected', 'Rejeitados'],
    Completed: ['Completed', 'Concluídos'],
  };

  /** All six counts, keyed by stable English names (language-independent). */
  async getAllCounts(): Promise<Record<string, number | null>> {
    const out: Record<string, number | null> = {};
    for (const [key, aliases] of Object.entries(InitiatorDashboardPage.COUNT_CARDS)) {
      out[key] = await this.getCount(aliases);
    }
    return out;
  }

  statusFilter(): Locator {
    return this.page.locator('select').first();
  }

  /** Select a status in the filter dropdown and wait for the table to settle. */
  async filterByStatus(statusLabel: string): Promise<void> {
    await this.statusFilter().selectOption({ label: statusLabel }).catch(async () => {
      await this.statusFilter().selectOption(statusLabel);
    });
    await this.page.waitForTimeout(800);
  }

  /** Open the toolbar search and type a term. Returns true if a search input appeared. */
  async search(term: string): Promise<boolean> {
    // The magnifier in the toolbar toggles a search box.
    const magnifier = this.page
      .locator('svg, button')
      .filter({ has: this.page.locator('title:has-text("Pesquisar")') })
      .first();
    // Fallback: click any toolbar button whose title mentions search/pesquisar.
    await this.page
      .locator('[title*="Pesquis" i], [title*="Search" i], button[aria-label*="search" i]')
      .first()
      .click()
      .catch(() => magnifier.click().catch(() => {}));
    await this.page.waitForTimeout(400);

    const input = this.page.locator('input[type="text"], input:not([type]), input[type="search"]').first();
    if (await input.isVisible().catch(() => false)) {
      await input.fill(term);
      await input.press('Enter').catch(() => {});
      await this.page.waitForTimeout(900);
      return true;
    }
    return false;
  }

  /** Locate the row for a given request number. */
  rowFor(reqNo: string): Locator {
    return this.rows().filter({ hasText: reqNo }).first();
  }

  /** Find the first draft row (status DRAFT / RASCUNHO) — language-independent. */
  firstDraftRow(): Locator {
    return this.rows().filter({ hasText: /RASCUNHO|DRAFT/i }).first();
  }

  /** Select the Draft option in the status filter (English or Portuguese). */
  async filterByDraft(): Promise<void> {
    const sel = this.statusFilter();
    // Try selecting by either label; fall back to the matching option value.
    for (const label of ['Draft', 'Rascunho']) {
      try {
        await sel.selectOption({ label });
        await this.page.waitForTimeout(800);
        return;
      } catch {
        /* try next */
      }
    }
    // Last resort: pick the option whose text matches draft in either language.
    const value = await sel
      .locator('option')
      .filter({ hasText: /Draft|Rascunho/i })
      .first()
      .getAttribute('value')
      .catch(() => null);
    if (value !== null) {
      await sel.selectOption(value);
      await this.page.waitForTimeout(800);
    }
  }

  async requestNoOf(row: Locator): Promise<string> {
    const link = row.locator('a.req-link').first();
    return (await link.innerText().catch(() => '')).trim();
  }

  // ----- Modals -----

  /** Open comments modal for a row; returns the modal heading text. */
  async openComments(row: Locator): Promise<string> {
    await row.locator('button.comment-btn').first().click();
    const heading = this.page
      .locator('text=/Coment[áa]rios da Solicita|Request Comments|Comments/i')
      .first();
    await heading.waitFor({ state: 'visible', timeout: 8_000 });
    return (await heading.innerText()).trim();
  }

  /** Open logs modal for a row; returns the modal heading text. */
  async openLogs(row: Locator): Promise<string> {
    await row.locator('button.log-btn').first().click();
    const heading = this.page
      .locator('text=/Registros da Solicita|Request Logs|Logs/i')
      .first();
    await heading.waitFor({ state: 'visible', timeout: 8_000 });
    return (await heading.innerText()).trim();
  }

  async closeModal(): Promise<void> {
    await this.page
      .locator('button:has-text("Fechar"), button:has-text("Close"), [aria-label="Close"]')
      .first()
      .click()
      .catch(() => this.page.keyboard.press('Escape'));
    await this.page.waitForTimeout(400);
  }

  rowHasEdit(row: Locator): Locator {
    // title is "Editar" (PT) or "Edit" (EN).
    return row.locator('button.dash-action-btn[title="Editar"], button.dash-action-btn[title="Edit"]');
  }

  rowHasDelete(row: Locator): Locator {
    // title is "Excluir" (PT) or "Delete" (EN).
    return row.locator('button.dash-action-btn[title="Excluir"], button.dash-action-btn[title="Delete"]');
  }

  rowHasView(row: Locator): Locator {
    // Non-draft rows show an eye/view control instead of edit+delete.
    return row.locator('button[title*="Ver" i], button[title*="View" i], button[title*="Visualiz" i]');
  }
}
