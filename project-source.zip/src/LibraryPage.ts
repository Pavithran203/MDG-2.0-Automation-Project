import { type Page, type Locator, type Download } from '@playwright/test';

/**
 * Shared Page Object for the read-only "library" pages:
 *   - Noun-Modifier Library      (scenario 7)
 *   - Attribute Name Library     (scenario 8)
 *   - Template Library           (scenario 9)
 *   - Attribute Value Master     (scenario 10)
 *
 * Common structure (confirmed via discovery, UI in Portuguese):
 *   - A data table (paginated) built from admin-created data.
 *   - A "Pesquisar" (Search) button and/or a search input; some pages reveal
 *     search inputs via an "Adicionar Filtro" (Add Filter) button.
 *   - A "Limpar Filtros" (Clear Filters) button.
 *   - An export/download button ("Exportar como Excel" / "Exportar como CSV").
 *   - No create/edit/delete controls (read-only).
 */
export class LibraryPage {
  constructor(
    readonly page: Page,
    readonly url: string,
  ) {}

  async goto(): Promise<void> {
    await this.page.goto(this.url, { waitUntil: 'networkidle', timeout: 30_000 }).catch(async () => {
      await this.page.goto(this.url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    });
    await this.table().waitFor({ state: 'visible', timeout: 20_000 }).catch(() => {});
    await this.page.waitForTimeout(500);
  }

  table(): Locator {
    return this.page.locator('table').first();
  }

  rows(): Locator {
    return this.table().locator('tbody tr');
  }

  async rowCount(): Promise<number> {
    return this.rows().count().catch(() => 0);
  }

  /** The text of the first data cell of the first row (used to craft a valid search). */
  async firstCellText(): Promise<string> {
    const cell = this.rows().first().locator('td').first();
    return (await cell.innerText().catch(() => '')).trim();
  }

  /** Reveal a search input if the page hides it behind "Adicionar Filtro". */
  async ensureSearchInput(): Promise<Locator | null> {
    let input = this.page.locator('input[placeholder*="Pesquis" i], input[type="search"], input[type="text"]').first();
    if (await input.isVisible().catch(() => false)) return input;

    // Try revealing filters.
    const addFilter = this.page.getByRole('button', { name: /Adicionar Filtro|Add Filter/i }).first();
    if (await addFilter.isVisible().catch(() => false)) {
      await addFilter.click().catch(() => {});
      await this.page.waitForTimeout(500);
      input = this.page.locator('input[placeholder*="Pesquis" i], input[type="search"], input[type="text"]').first();
      if (await input.isVisible().catch(() => false)) return input;
    }
    return null;
  }

  /** Type a term into the first search input and trigger search. */
  async search(term: string): Promise<boolean> {
    const input = await this.ensureSearchInput();
    if (!input) return false;
    await input.fill(term);
    // Prefer an explicit Pesquisar button; fall back to Enter.
    const btn = this.page.getByRole('button', { name: /^Pesquisar$|^Search$/i }).first();
    if (await btn.isVisible().catch(() => false)) {
      await btn.click();
    } else {
      await input.press('Enter');
    }
    await this.page.waitForTimeout(1200);
    return true;
  }

  /** Clear filters to restore the full list. */
  async clearFilters(): Promise<void> {
    const btn = this.page.getByRole('button', { name: /Limpar Filtros|Clear Filters|Redefinir|Reset/i }).first();
    if (await btn.isVisible().catch(() => false)) {
      await btn.click();
      await this.page.waitForTimeout(800);
    }
  }

  /** Click the export/download button and return the triggered Download, or null. */
  async download(): Promise<Download | null> {
    const btn = this.page
      .getByRole('button', { name: /Exportar como Excel|Exportar como CSV|Export|Download|Baixar/i })
      .first();
    if (!(await btn.isVisible().catch(() => false))) return null;

    const [dl] = await Promise.all([
      this.page.waitForEvent('download', { timeout: 15_000 }).catch(() => null),
      btn.click(),
    ]);
    return dl;
  }

  /**
   * Heuristic read-only check: the page must NOT expose create/edit/delete
   * controls typical of editable grids.
   */
  async hasMutationControls(): Promise<boolean> {
    const count = await this.page
      .locator(
        [
          'button[title="Editar"]',
          'button[title="Excluir"]',
          'button:has-text("Adicionar Valor")',
          'button:has-text("Add Value")',
          'button:has-text("Novo")',
          'button:has-text("Criar")',
          'button:has-text("Delete")',
          'button.dash-action-btn',
        ].join(', '),
      )
      .filter({ has: this.page.locator(':scope') })
      .count()
      .catch(() => 0);
    // Only count visible ones.
    if (count === 0) return false;
    const visible = await this.page
      .locator('button[title="Editar"], button[title="Excluir"], button.dash-action-btn')
      .filter({ hasNot: this.page.locator('[hidden]') })
      .first()
      .isVisible()
      .catch(() => false);
    return visible;
  }
}
