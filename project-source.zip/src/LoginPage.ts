import { type Page, type Locator, expect } from '@playwright/test';
import type { RoleCredentials } from './roles.js';

/**
 * Page Object for the MDG 2.0 login screen.
 *
 * NOTE: The selectors below use several fallback strategies because the exact
 * markup of the login form has not been inspected yet. Once we confirm the real
 * element ids / names / placeholders, these can be tightened to single, stable
 * selectors. See the `discover()` helper + the discover.spec.ts test for a way
 * to dump the real selectors.
 */
export class LoginPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto(): Promise<void> {
    await this.page.goto('/login', { waitUntil: 'domcontentloaded' });
  }

  /** Find the username / email input using a prioritised list of strategies. */
  private usernameField(): Locator {
    const p = this.page;
    return p
      .locator(
        [
          'input[type="email"]',
          'input[name="email" i]',
          'input[name="username" i]',
          'input[name="user" i]',
          'input[id*="email" i]',
          'input[id*="user" i]',
          'input[placeholder*="email" i]',
          'input[placeholder*="user" i]',
        ].join(', '),
      )
      .first();
  }

  private passwordField(): Locator {
    const p = this.page;
    return p
      .locator(
        [
          'input[type="password"]',
          'input[name="password" i]',
          'input[id*="password" i]',
          'input[placeholder*="password" i]',
        ].join(', '),
      )
      .first();
  }

  private submitButton(): Locator {
    const p = this.page;
    // Prefer a real submit button; fall back to common login button text.
    return p
      .locator(
        [
          'button[type="submit"]',
          'input[type="submit"]',
          'button:has-text("Login")',
          'button:has-text("Log in")',
          'button:has-text("Sign in")',
          'button:has-text("Sign In")',
          'button:has-text("Submit")',
        ].join(', '),
      )
      .first();
  }

  /**
   * Fill in credentials and submit. Returns after the submit click; the caller
   * should assert the post-login state (which differs per role).
   */
  async login(creds: RoleCredentials): Promise<void> {
    await this.goto();

    const username = this.usernameField();
    const password = this.passwordField();

    await expect(username, 'username/email field should be visible').toBeVisible();
    await username.fill(creds.username);

    await expect(password, 'password field should be visible').toBeVisible();
    await password.fill(creds.password);

    const submit = this.submitButton();
    await expect(submit, 'submit button should be visible').toBeVisible();

    await Promise.all([
      this.page
        .waitForURL((url) => !url.pathname.toLowerCase().includes('/login'), {
          timeout: 20_000,
        })
        .catch(() => {
          /* some apps stay on the same URL and swap content; don't hard-fail here */
        }),
      submit.click(),
    ]);
  }

  /**
   * Heuristic check that we are logged in: we are no longer on the /login page,
   * and no visible error/invalid-credentials message is present.
   */
  async assertLoggedIn(creds: RoleCredentials): Promise<void> {
    const url = this.page.url();
    expect(
      url.toLowerCase(),
      `${creds.label}: should have navigated away from /login (still at ${url})`,
    ).not.toContain('/login');

    // Look for a few common error indicators and fail loudly if present.
    const errorLocator = this.page.locator(
      [
        'text=/invalid/i',
        'text=/incorrect/i',
        'text=/failed/i',
        'text=/wrong password/i',
        '[role="alert"]',
      ].join(', '),
    );

    if (await errorLocator.first().isVisible().catch(() => false)) {
      const text = await errorLocator.first().innerText().catch(() => '');
      throw new Error(`${creds.label}: login appears to have failed - "${text}"`);
    }
  }

  /**
   * Log in using a raw email/password pair (for negative / edge-case testing
   * where we don't have a full RoleCredentials object).
   */
  async loginWith(username: string, password: string): Promise<void> {
    await this.goto();

    const user = this.usernameField();
    const pass = this.passwordField();

    if (username.length > 0) {
      await user.fill(username);
    }
    if (password.length > 0) {
      await pass.fill(password);
    }

    const submit = this.submitButton();
    await Promise.all([
      this.page
        .waitForURL((url) => !url.pathname.toLowerCase().includes('/login'), {
          timeout: 8_000,
        })
        .catch(() => {
          /* staying on /login is expected for negative cases */
        }),
      submit.click().catch(() => {
        /* a disabled submit button (empty-field validation) may not click */
      }),
    ]);
  }

  /** True if the browser is still on the /login route. */
  isOnLoginPage(): boolean {
    return this.page.url().toLowerCase().includes('/login');
  }

  /**
   * Regex of known login error/validation phrases (English + Portuguese).
   */
  private static readonly MESSAGE_PATTERN =
    /invalid|incorrect|wrong|inactive|not active|disabled|deactivat|blocked|locked|contact|unauthor|denied|fail|required|inválid|inativ|desativ|bloquead|incorret|credenc|obrigat|necessári/i;

  /**
   * Wait for and return the first visible validation / error message on the
   * login page, or null if none appears within the timeout.
   *
   * The MDG login form renders the error as a plain text node (not a role=alert),
   * and it may appear a beat after the submit request resolves, so we poll.
   */
  async getValidationMessage(timeout = 6_000): Promise<string | null> {
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
      // Scan the small set of text nodes inside the login card for a known phrase.
      const found = await this.page
        .evaluate((patternSource) => {
          const re = new RegExp(patternSource, 'i');
          const nodes = Array.from(document.querySelectorAll('body *'));
          for (const node of nodes) {
            const el = node as HTMLElement;
            // Only leaf-ish elements with their own short text.
            if (el.children.length > 2) continue;
            const text = (el.textContent ?? '').trim();
            if (!text || text.length > 120) continue;
            if (!re.test(text)) continue;
            // Must be visible.
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);
            const visible =
              rect.width > 0 &&
              rect.height > 0 &&
              style.visibility !== 'hidden' &&
              style.display !== 'none' &&
              style.opacity !== '0';
            if (visible) return text;
          }
          return null;
        }, LoginPage.MESSAGE_PATTERN.source)
        .catch(() => null);

      if (found) return found;
      await this.page.waitForTimeout(200);
    }
    return null;
  }

  /** Report whether the native HTML5 validation is blocking an empty field. */
  async isFieldInvalid(which: 'username' | 'password'): Promise<boolean> {
    const field = which === 'username' ? this.usernameField() : this.passwordField();
    return field
      .evaluate((el) => {
        const input = el as HTMLInputElement;
        return typeof input.checkValidity === 'function' ? !input.checkValidity() : false;
      })
      .catch(() => false);
  }
}
