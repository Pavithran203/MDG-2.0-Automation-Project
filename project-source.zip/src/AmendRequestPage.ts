import { type Page, type Locator, expect } from '@playwright/test';

async function expectEnabled(locator: Locator): Promise<void> {
  await expect(locator).toBeEnabled({ timeout: 8_000 });
}

/**
 * Page Object for the Amend Request flow (scenario 4).
 *
 * Flow (confirmed via discovery, UI in Portuguese):
 *   1. From New Request page there's a "Solicitação de Emenda" (Amend) link,
 *      or go directly to /app/request/amend-request.
 *   2. Enter a material number -> "Pesquisar" (Search).
 *   3. Select the result row's checkbox.
 *   4. Click "Adicionar Materiais Para Emenda" (Add Materials for Amendment)
 *      -> opens the request editor (new-request editor with the line item).
 *   5. "Enviar Solicitação" (Submit Request) -> goes to validator.
 */
export class AmendRequestPage {
  constructor(readonly page: Page) {}

  async gotoNewRequest(): Promise<void> {
    await this.page.goto('/app/request/new-request', { waitUntil: 'networkidle', timeout: 30_000 }).catch(() => {});
    await this.page.waitForTimeout(800);
  }

  async gotoAmend(): Promise<void> {
    await this.page.goto('/app/request/amend-request', { waitUntil: 'networkidle', timeout: 30_000 }).catch(async () => {
      await this.page.goto('/app/request/amend-request', { waitUntil: 'domcontentloaded', timeout: 30_000 });
    });
    await this.page.waitForTimeout(800);
  }

  /** Click the "Solicitação de Emenda" link found on the new-request page. */
  amendLink(): Locator {
    return this.page.getByRole('link', { name: /Solicita[çc][aã]o de Emenda|Amend Request|Amend/i }).first();
  }

  materialInput(): Locator {
    return this.page.locator('textarea').first();
  }

  searchButton(): Locator {
    return this.page.getByRole('button', { name: /^Pesquisar$|^Search$/i }).first();
  }

  rows(): Locator {
    return this.page.locator('table tbody tr');
  }

  addForAmendButton(): Locator {
    return this.page
      .getByRole('button', { name: /Adicionar Materiais Para Emenda|Add Materials (for|to) Amend|Add to Amend/i })
      .first();
  }

  /** The "Emenda" / "Amend" action button revealed after adding materials to the cart. */
  emendaButton(): Locator {
    return this.page.getByRole('button', { name: /^Emenda$|^Amend$/i }).first();
  }

  rowCheckbox(): Locator {
    return this.rows().first().locator('input[type="checkbox"]').first();
  }

  submitButton(): Locator {
    return this.page
      .getByRole('button', { name: /Enviar Solicita[çc][aã]o|Submit Request|Enviar para Valida|^Enviar$/i })
      .first();
  }

  /** Search a material number and select its result row. Returns true if selected. */
  async searchAndSelect(materialNo: string): Promise<boolean> {
    await this.materialInput().fill(materialNo);
    await this.searchButton().click();
    await this.page.waitForTimeout(2000);
    return this.selectFirstSelectableRow();
  }

  /**
   * Run an unfiltered search and select the first material that is NOT already
   * blocked by an existing request (empty "Bloqueado por" cell). Returns the
   * selected material number, or '' if none selectable.
   *
   * This avoids the test-data pitfall where a material gets locked by a prior
   * amend submission and can no longer be selected.
   */
  async searchAllAndSelectUnblocked(): Promise<string> {
    await this.materialInput().fill('');
    await this.searchButton().click();
    await this.page.waitForTimeout(2500);

    const count = await this.rows().count().catch(() => 0);
    for (let i = 0; i < count; i++) {
      const row = this.rows().nth(i);
      const cb = row.locator('input[type="checkbox"]').first();
      if (!(await cb.isVisible().catch(() => false))) continue;
      if (!(await cb.isEnabled().catch(() => false))) continue;
      // The last cell ("Bloqueado por") should be empty / dash for an unblocked material.
      const blockedText = (await row.locator('td').last().innerText().catch(() => '')).trim();
      if (blockedText && !/^[—\-\s]*$/.test(blockedText)) continue; // skip blocked rows
      await cb.click({ force: true });
      await this.page.waitForTimeout(400);
      if (await cb.isChecked().catch(() => false)) {
        return (await row.locator('td').nth(1).innerText().catch(() => '')).trim();
      }
    }
    return '';
  }

  /** Select the first selectable (visible, enabled, unblocked) checkbox row. */
  private async selectFirstSelectableRow(): Promise<boolean> {
    const count = await this.rows().count().catch(() => 0);
    for (let i = 0; i < count; i++) {
      const row = this.rows().nth(i);
      const cb = row.locator('input[type="checkbox"]').first();
      if (!(await cb.isVisible().catch(() => false))) continue;
      if (!(await cb.isEnabled().catch(() => false))) continue;
      const blockedText = (await row.locator('td').last().innerText().catch(() => '')).trim();
      if (blockedText && !/^[—\-\s]*$/.test(blockedText)) continue;
      await cb.click({ force: true });
      await this.page.waitForTimeout(400);
      if (await cb.isChecked().catch(() => false)) return true;
    }
    return false;
  }

  /**
   * Click "Adicionar Materiais Para Emenda". This reveals an "A Ser Alterado"
   * (To Be Changed) cart panel with a REQUIRED "Descrição" (description) field
   * and an "Emenda" button. We fill the description, then click "Emenda" to
   * proceed into the request editor.
   */
  async addToAmend(description = 'Automated amend test — update material attributes'): Promise<void> {
    const addBtn = this.addForAmendButton();
    // Re-affirm selection right before clicking (grid can reset it on re-render).
    const cb = this.rowCheckbox();
    if (!(await cb.isChecked().catch(() => false))) {
      await cb.click({ force: true }).catch(() => {});
      await this.page.waitForTimeout(300);
    }
    await expectEnabled(addBtn).catch(() => {});
    await addBtn.click();
    await this.page.waitForTimeout(1500);

    // The cart panel has a required description textarea (EN or PT placeholder).
    const descField = this.page
      .locator(
        'textarea[placeholder*="Descreva" i], textarea[placeholder*="alterado" i], textarea[placeholder*="Describe" i], textarea[placeholder*="being changed" i]',
      )
      .first();
    if (await descField.isVisible().catch(() => false)) {
      await descField.fill(description);
      await this.page.waitForTimeout(300);
    }

    // Now click the "Emenda" button to proceed to the editor.
    const emenda = this.emendaButton();
    if (await emenda.isVisible().catch(() => false)) {
      await emenda.click();
      await this.page.waitForTimeout(3000);
    }
    await this.page.waitForLoadState('networkidle').catch(() => {});
  }

  /** Submit the request to the validator. Returns a confirmation/snapshot string. */
  async submit(): Promise<string> {
    const submit = this.submitButton();
    await submit.scrollIntoViewIfNeeded().catch(() => {});
    await submit.click();
    await this.page.waitForTimeout(1500);

    // A confirmation dialog may ask to confirm submission.
    const confirm = this.page.getByRole('button', { name: /^(Confirmar|Confirm|Enviar|Submit|Sim|Yes|OK)$/i }).last();
    if (await confirm.isVisible().catch(() => false)) {
      await confirm.click();
      await this.page.waitForTimeout(2000);
    }
    await this.page.waitForLoadState('networkidle').catch(() => {});

    // Capture any success toast / message text (EN or PT).
    const toast = this.page
      .locator('text=/sucesso|enviad|submitted|validador|validator|success|sent/i')
      .first();
    const msg = (await toast.innerText().catch(() => '')).trim();
    return msg || `submitted (url=${this.page.url()})`;
  }
}
