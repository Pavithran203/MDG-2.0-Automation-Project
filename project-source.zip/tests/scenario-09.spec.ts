import { registerLibraryScenario } from '../src/libraryScenario.js';

/**
 * Scenario 9 — Template Library (read-only, admin-created data).
 * Run independently: npx playwright test tests/scenario-09.spec.ts
 */
registerLibraryScenario({
  scenario: 'scenario-09',
  title: 'Scenario 9 — Template Library',
  url: '/app/initiator/template-library',
  idPrefix: 'TC-S9',
});
