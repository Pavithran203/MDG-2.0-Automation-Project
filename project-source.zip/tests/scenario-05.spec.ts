import { test, expect, type Page } from '@playwright/test';
import { ROLES } from '../src/roles.js';
import { LoginPage } from '../src/LoginPage.js';
import { MaterialSearchPage } from '../src/MaterialSearchPage.js';
import { ResultsReporter, type TestCaseResult } from '../src/resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

/**
 * Scenario 5 — Material Search.
 *   - Enter a material number and search
 *   - Results listed
 *   - Search (all) lists all material data
 *   - Action button opens the material/request details
 */
test.describe.serial('Scenario 5 — Material Search', () => {
  let reporter: ResultsReporter;
  let sampleMaterialNo = '';

  test.beforeAll(() => {
    reporter = new ResultsReporter({ scenario: 'scenario-05', title: 'Scenario 5 — Material Search', baseUrl: BASE_URL });
    console.log(`\n[results] scenario-05 -> ${reporter.runDir}`);
  });
  test.afterAll(() => {
    console.log(`[results] scenario-05 saved -> ${reporter.finalize()}`);
  });

  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    await login.login(ROLES.initiator);
    await login.assertLoggedIn(ROLES.initiator);
  });

  async function record(page: Page, rec: Omit<TestCaseResult, 'status'>, body: () => Promise<string>): Promise<void> {
    const started = Date.now();
    const full: TestCaseResult = { status: 'failed', ...rec };
    try {
      full.actual = await body();
      full.status = 'passed';
    } catch (err) {
      full.actual = `Error: ${(err as Error).message}`;
      await page.screenshot({ path: reporter.screenshotPath(rec.id), fullPage: true }).catch(() => {});
      full.status = 'failed';
      throw err;
    } finally {
      full.durationMs = Date.now() - started;
      reporter.add(full);
    }
  }

  // --- Search all -> lists all data (also captures a valid material no for TC-02) ---
  test('TC-S5-01 | Search button lists all material data', async ({ page }) => {
    const ms = new MaterialSearchPage(page);
    await ms.goto();
    await record(
      page,
      { id: 'TC-S5-01', title: 'Clicking Search lists all material search data', expected: 'Results table is populated' },
      async () => {
        await ms.searchAll();
        const count = await ms.rowCount();
        expect(count, 'search should list material data').toBeGreaterThan(0);
        sampleMaterialNo = await ms.firstMaterialNumber();
        return `Search-all returned ${count} row(s); sample material no = ${sampleMaterialNo}`;
      },
    );
  });

  // --- Search by a valid material number ---
  test('TC-S5-02 | Enter a material number and search returns matching results', async ({ page }) => {
    const ms = new MaterialSearchPage(page);
    await ms.goto();
    await record(
      page,
      {
        id: 'TC-S5-02',
        title: 'Enter material number in the field and Search lists matching details',
        input: 'a valid material number (from TC-S5-01)',
        expected: 'The searched material is listed',
      },
      async () => {
        // Ensure we have a material number (from TC-01); otherwise fetch one.
        if (!sampleMaterialNo) {
          await ms.searchAll();
          sampleMaterialNo = await ms.firstMaterialNumber();
        }
        await ms.goto();
        await ms.searchByNumber(sampleMaterialNo);
        const count = await ms.rowCount();
        expect(count, 'valid material-number search should return results').toBeGreaterThan(0);
        const firstNo = await ms.firstMaterialNumber();
        expect(firstNo, 'returned row should match the searched material').toContain(sampleMaterialNo);
        return `Searched material ${sampleMaterialNo} -> ${count} row(s); top result = ${firstNo}`;
      },
    );
  });

  // --- Invalid material number ---
  test('TC-S5-03 | Invalid material number returns no results', async ({ page }) => {
    const ms = new MaterialSearchPage(page);
    await ms.goto();
    await record(
      page,
      { id: 'TC-S5-03', title: 'Invalid material number returns no results', input: '999999999999NONE', expected: 'No rows / empty state' },
      async () => {
        await ms.searchByNumber('999999999999NONE');
        const count = await ms.rowCount();
        const bodyText = (await ms.table().innerText().catch(() => '')).toLowerCase();
        const emptyState = /nenhum|no data|sem resultados|não encontrad|no records/i.test(bodyText);
        expect(count === 0 || emptyState, `invalid search should yield no data (rows=${count})`).toBe(true);
        return `Invalid search -> rows=${count}, emptyState=${emptyState}`;
      },
    );
  });

  // --- Action button -> material/request details ---
  test('TC-S5-04 | Action button opens the material/request details', async ({ page }) => {
    const ms = new MaterialSearchPage(page);
    await ms.goto();
    await record(
      page,
      { id: 'TC-S5-04', title: 'Action button opens the material details view', expected: 'A material detail view/page opens' },
      async () => {
        await ms.searchAll();
        expect(await ms.rowCount(), 'need at least one row').toBeGreaterThan(0);
        const row = ms.rows().first();
        const matNo = (await row.locator('td').first().innerText().catch(() => '')).trim();
        await ms.rowAction(row).click();
        await page.waitForTimeout(1500);
        await page.waitForLoadState('networkidle').catch(() => {});

        // Give the detail view/modal a moment to render, then check EN or PT text.
        const detailVisible = await page
          .locator(
            'text=/Detalhe do Material|Material Detail|Detalhes|Details|Descri[çc][aã]o Longa|Long Description|Especifica|Specification|Attributes|Atributos/i',
          )
          .first()
          .waitFor({ state: 'visible', timeout: 6_000 })
          .then(() => true)
          .catch(() => false);
        const navigated = !page.url().toLowerCase().endsWith('/material-search');
        const dialogOpen = await page.locator('[role="dialog"], .modal').first().isVisible().catch(() => false);
        expect(detailVisible || navigated || dialogOpen, 'action should open material details').toBe(true);
        return `Opened details for ${matNo}; url=${page.url()}; detailVisible=${detailVisible}`;
      },
    );
  });
});
