import { test, expect, type Page } from '@playwright/test';
import { ROLES } from '../src/roles.js';
import { LoginPage } from '../src/LoginPage.js';
import { AmendRequestPage } from '../src/AmendRequestPage.js';
import { ResultsReporter, type TestCaseResult } from '../src/resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

/**
 * Scenario 4 — Amend Request.
 *   - Open Amend Request (from the new-request page)
 *   - Search a material Id and select the line item
 *   - Click the Amend button ("Adicionar Materiais Para Emenda")
 *   - Submit the request -> goes to validator (REAL submit)
 */
test.describe.serial('Scenario 4 — Amend Request', () => {
  let reporter: ResultsReporter;
  // Dynamically selected unblocked material number (captured in TC-S4-02).
  let selectedMaterial = '';

  test.beforeAll(() => {
    reporter = new ResultsReporter({ scenario: 'scenario-04', title: 'Scenario 4 — Amend Request', baseUrl: BASE_URL });
    console.log(`\n[results] scenario-04 -> ${reporter.runDir}`);
  });
  test.afterAll(() => {
    console.log(`[results] scenario-04 saved -> ${reporter.finalize()}`);
  });

  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    await login.login(ROLES.initiator);
    await login.assertLoggedIn(ROLES.initiator);
  });

  async function record(page: Page, rec: Omit<TestCaseResult, 'status'>, body: () => Promise<string>): Promise<void> {
    const started = Date.now();
    const full: TestCaseResult = { status: 'failed', ...rec };
    try {
      full.actual = await body();
      full.status = 'passed';
    } catch (err) {
      full.actual = `Error: ${(err as Error).message}`;
      await page.screenshot({ path: reporter.screenshotPath(rec.id), fullPage: true }).catch(() => {});
      full.status = 'failed';
      throw err;
    } finally {
      full.durationMs = Date.now() - started;
      reporter.add(full);
    }
  }

  // --- TC-S4-01: Amend entry point exists on the new-request page ---
  test('TC-S4-01 | Open Amend Request from the create-new-request page', async ({ page }) => {
    const amend = new AmendRequestPage(page);
    await amend.gotoNewRequest();
    await record(
      page,
      { id: 'TC-S4-01', title: 'Amend Request option is reachable from the new-request page', expected: 'Amend link present; opens the Amend page' },
      async () => {
        await expect(amend.amendLink(), 'Amend link should be present').toBeVisible();
        await amend.amendLink().click();
        await page.waitForTimeout(1500);
        expect(page.url()).toContain('amend-request');
        return `Amend link opened ${page.url()}`;
      },
    );
  });

  // --- TC-S4-02: Search material and select line item ---
  test('TC-S4-02 | Search material Id and select the line item', async ({ page }) => {
    const amend = new AmendRequestPage(page);
    await amend.gotoAmend();
    await record(
      page,
      { id: 'TC-S4-02', title: 'Search a material Id and select the result line item', input: 'first unblocked material', expected: 'Result row found and selected' },
      async () => {
        selectedMaterial = await amend.searchAllAndSelectUnblocked();
        expect(selectedMaterial.length, 'an unblocked result row should be found and selectable').toBeGreaterThan(0);
        return `Found and selected unblocked material ${selectedMaterial}.`;
      },
    );
  });

  // --- TC-S4-03 + 04: Amend button -> submit to validator (REAL) ---
  test('TC-S4-03 | Amend and submit the request to the validator', async ({ page }) => {
    const amend = new AmendRequestPage(page);
    await amend.gotoAmend();
    await record(
      page,
      {
        id: 'TC-S4-03',
        title: 'Click Amend, then Submit the request to the validator',
        input: 'first unblocked material',
        expected: 'Request is submitted and routed to the validator',
      },
      async () => {
        const material = await amend.searchAllAndSelectUnblocked();
        expect(material.length, 'need a selectable unblocked result row').toBeGreaterThan(0);

        await expect(amend.addForAmendButton(), 'Amend (Add for Amendment) button should appear').toBeVisible();
        await amend.addToAmend();

        // We should now be in the request editor with the line item. Accept either
        // the line-items UI appearing OR navigation to the new-request editor.
        const editorReady = await page
          .locator('text=/Itens de Linha|Line Items|Enviar Solicita|Submit Request|Adicionar Item|Add Item/i')
          .first()
          .waitFor({ state: 'visible', timeout: 10_000 })
          .then(() => true)
          .catch(() => false);
        const onEditorUrl = /new-request|request\//i.test(page.url());
        expect(editorReady || onEditorUrl, `request editor should open (url=${page.url()})`).toBe(true);

        await expect(amend.submitButton(), 'Submit button should be present').toBeVisible();
        const result = await amend.submit();

        // Confirm we are no longer in an un-submitted editor: either a success
        // message appeared or we navigated away (e.g. back to dashboard).
        const success = /sucesso|enviad|submitted|validador|validator|success/i.test(result);
        const navigatedAway = /dashboard|request-search/i.test(page.url());
        expect(success || navigatedAway, `submission should be confirmed (got: "${result}", url=${page.url()})`).toBe(true);
        return `Amended material ${material} and submitted. Result: "${result}"; url=${page.url()}`;
      },
    );
  });
});
