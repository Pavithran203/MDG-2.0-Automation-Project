import { registerLibraryScenario } from '../src/libraryScenario.js';

/**
 * Scenario 8 — Attribute Name Library (read-only, admin-created data).
 * Run independently: npx playwright test tests/scenario-08.spec.ts
 */
registerLibraryScenario({
  scenario: 'scenario-08',
  title: 'Scenario 8 — Attribute Name Library',
  url: '/app/initiator/attribute-name-library',
  idPrefix: 'TC-S8',
});
