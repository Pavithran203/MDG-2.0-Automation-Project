import { test, expect, type Locator } from '@playwright/test';
import { ROLES } from '../src/roles.js';
import { LoginPage } from '../src/LoginPage.js';
import { InitiatorDashboardPage } from '../src/InitiatorDashboardPage.js';
import { ResultsReporter, type TestCaseResult } from '../src/resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

/**
 * Initiator Dashboard scenario suite.
 *
 * Covers:
 *   TC-DASH-01  overall data counts display correctly
 *   TC-DASH-02  search / filter returns matching results (valid)
 *   TC-DASH-03  search / filter with no match shows empty result (invalid)
 *   TC-DASH-04  comments icon opens the comments view
 *   TC-DASH-05  action button shows the line-item / request details
 *   TC-DASH-06  logs icon shows the log history
 *   TC-DASH-07  draft request exposes edit + delete (non-draft does not)
 *   TC-DASH-08  delete confirmation works for a draft (safe: cancels unless
 *               ALLOW_DELETE=true)
 *
 * Results saved to: results/initiator/<timestamp>/
 */
test.describe.serial('Initiator Dashboard scenarios', () => {
  let reporter: ResultsReporter;

  test.beforeAll(() => {
    reporter = new ResultsReporter({ scenario: 'scenario-03', title: 'Scenario 3 — Initiator Dashboard', baseUrl: BASE_URL });
    console.log(`\n[results] saving this run to: ${reporter.runDir}\n`);
  });

  test.afterAll(() => {
    console.log(`\n[results] run saved -> ${reporter.finalize()}\n`);
  });

  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    await login.login(ROLES.initiator);
    await login.assertLoggedIn(ROLES.initiator);
  });

  /** Helper to wrap a test body with result recording. */
  async function record(
    rec: Omit<TestCaseResult, 'status'> & { status?: TestCaseResult['status'] },
    body: () => Promise<string>,
  ): Promise<void> {
    const started = Date.now();
    const full: TestCaseResult = { status: 'failed', ...rec };
    try {
      full.actual = await body();
      full.status = 'passed';
    } catch (err) {
      full.actual = `Error: ${(err as Error).message}`;
      full.status = 'failed';
      throw err;
    } finally {
      full.durationMs = Date.now() - started;
      reporter.add(full);
    }
  }

  // ---------- TC-DASH-01 ----------
  test('TC-DASH-01 | Overall data counts display correctly', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-01',
        title: 'Overall data counts display correctly',
        expected: 'All 6 count cards render non-negative integers; Total >= sum of status cards',
      },
      async () => {
        const counts = await dash.getAllCounts();
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-01', 'TC-01-counts'), fullPage: true });

        // Every card must be a number >= 0.
        for (const [label, value] of Object.entries(counts)) {
          expect(value, `card "${label}" should show a number`).not.toBeNull();
          expect(value as number, `card "${label}" should be >= 0`).toBeGreaterThanOrEqual(0);
        }

        const total = counts['Total'] ?? 0;
        const parts =
          (counts['Draft'] ?? 0) +
          (counts['In Progress'] ?? 0) +
          (counts['Returned'] ?? 0) +
          (counts['Rejected'] ?? 0) +
          (counts['Completed'] ?? 0);
        // Total should be at least the sum of the shown status buckets.
        expect(total, 'Total should be >= sum of status cards').toBeGreaterThanOrEqual(parts);

        return `Counts -> ${JSON.stringify(counts)} (sum of status cards = ${parts})`;
      },
    );
  });

  // ---------- TC-DASH-02 (valid search/filter) ----------
  test('TC-DASH-02 | Search/filter with valid value returns results', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-02',
        title: 'Search/filter with valid value returns results',
        input: 'Status filter = Draft / Rascunho',
        expected: 'Table shows only matching (draft) rows, at least one',
      },
      async () => {
        await dash.filterByDraft();
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-02', 'TC-02-filter-valid'), fullPage: true });
        const rowCount = await dash.rows().count();
        expect(rowCount, 'at least one draft row should show').toBeGreaterThan(0);

        // Every visible row's status should read DRAFT / RASCUNHO.
        const statuses = await dash.rows().locator('td').filter({ hasText: /RASCUNHO|DRAFT/i }).count();
        expect(statuses, 'all visible rows should be drafts').toBeGreaterThan(0);
        return `Filter=Draft -> ${rowCount} row(s) shown`;
      },
    );
  });

  // ---------- TC-DASH-03 (invalid search) ----------
  test('TC-DASH-03 | Search with invalid value returns no results', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-03',
        title: 'Search with invalid value returns no results',
        input: 'Search term = ZZZNON-EXISTENT-REQ-999',
        expected: 'No rows / empty-state shown',
      },
      async () => {
        const searchable = await dash.search('ZZZNON-EXISTENT-REQ-999');
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-03', 'TC-03-search-invalid'), fullPage: true });
        if (!searchable) {
          return 'No free-text search control present on dashboard; search is via status filter only (see notes).';
        }
        const rowCount = await dash.rows().count();
        expect(rowCount, 'invalid search should yield zero matching rows').toBe(0);
        return `Invalid search -> ${rowCount} rows`;
      },
    );
  });

  // ---------- TC-DASH-04 (comments) ----------
  test('TC-DASH-04 | Comments icon opens the comments view', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-04',
        title: 'Comments icon opens the comments view',
        expected: 'A "Comentários da Solicitação" modal opens',
      },
      async () => {
        const row = dash.rows().first();
        const reqNo = await dash.requestNoOf(row);
        const heading = await dash.openComments(row);
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-04', 'TC-04-comments'), fullPage: true });
        expect(heading.toLowerCase()).toMatch(/coment|comment/);
        await dash.closeModal();
        return `Comments modal opened for ${reqNo}: "${heading}"`;
      },
    );
  });

  // ---------- TC-DASH-05 (action -> details) ----------
  test('TC-DASH-05 | Action button shows the request/line-item details', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-05',
        title: 'Action button shows the request/line-item details',
        expected: 'Opens the request (edit view for drafts) showing line items',
      },
      async () => {
        // Prefer a draft row that actually has a description (real line items).
        let row = dash.rows().filter({ hasText: /RASCUNHO|DRAFT/i }).filter({ hasText: /\w{3,}/ }).first();
        if ((await row.count()) === 0) row = dash.firstDraftRow();
        const reqNo = await dash.requestNoOf(row);

        // The scenario's "Action Button" is the Edit (pencil) icon in the Ações column.
        await dash.rowHasEdit(row).first().click();

        // The editor either navigates to a request route or renders a details view.
        await page
          .waitForURL((u) => !u.pathname.toLowerCase().endsWith('/dashboard'), { timeout: 10_000 })
          .catch(() => {});
        await page.waitForLoadState('networkidle').catch(() => {});
        await page.waitForTimeout(1000);
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-05', 'TC-05-details'), fullPage: true });

        const url = page.url();
        const navigated = !url.toLowerCase().endsWith('/dashboard');
        // "Line item details" view shows the Itens de Linha heading/section.
        const lineItemsVisible = await page
          .locator('text=/Itens de Linha|Line Items|Descri[çc][aã]o Longa|N[°º] de Linha/i')
          .first()
          .isVisible()
          .catch(() => false);

        expect(
          navigated || lineItemsVisible,
          'edit action should open the request / line-item details',
        ).toBe(true);
        return `Opened ${reqNo}; url=${url}; lineItemsVisible=${lineItemsVisible}`;
      },
    );
  });

  // ---------- TC-DASH-06 (logs) ----------
  test('TC-DASH-06 | Logs icon shows the log history', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-06',
        title: 'Logs icon shows the log history',
        expected: 'A "Registros da Solicitação" modal with a workflow timeline opens',
      },
      async () => {
        const row = dash.rows().first();
        const reqNo = await dash.requestNoOf(row);
        const heading = await dash.openLogs(row);

        // Wait for the modal body (timeline / step history) to render (EN or PT).
        const timeline = page
          .locator('text=/Linha do Tempo|Hist[óo]rico de Etapas|Fluxo de Trabalho|Criado|Pendente|Data \/ Hora|Workflow|Timeline|Step History|Created|Pending|Date \/ Time/i')
          .first();
        const hasTimeline = await timeline
          .waitFor({ state: 'visible', timeout: 6_000 })
          .then(() => true)
          .catch(() => false);
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-06', 'TC-06-logs'), fullPage: true });
        expect(heading.toLowerCase()).toMatch(/registros|logs/);
        expect(hasTimeline, 'log history/timeline should be visible').toBe(true);
        await dash.closeModal();
        return `Logs modal opened for ${reqNo}: "${heading}" (timeline visible: ${hasTimeline})`;
      },
    );
  });

  // ---------- TC-DASH-07 (draft shows edit+delete) ----------
  test('TC-DASH-07 | Draft request exposes Edit and Delete', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    await record(
      {
        id: 'TC-DASH-07',
        title: 'Draft request exposes Edit and Delete (non-draft does not)',
        expected: 'Draft row shows Edit + Delete; a non-draft row shows View instead',
      },
      async () => {
        const draft = dash.firstDraftRow();
        const draftNo = await dash.requestNoOf(draft);
        await expect(dash.rowHasEdit(draft), 'draft should have Edit').toBeVisible();
        await expect(dash.rowHasDelete(draft), 'draft should have Delete').toBeVisible();

        // A non-draft (In Progress / Completed etc.) row should NOT offer delete.
        const nonDraft = dash
          .rows()
          .filter({ hasText: /EM ANDAMENTO|CONCLU[ÍI]DO|REJEITAD|DEVOLVID|IN PROGRESS|COMPLETED|REJECTED|RETURNED/i })
          .first();
        let nonDraftNote = 'no non-draft row on page 1 to compare';
        if ((await nonDraft.count()) > 0) {
          const deleteVisible = await dash.rowHasDelete(nonDraft).isVisible().catch(() => false);
          expect(deleteVisible, 'non-draft row should NOT offer delete').toBe(false);
          nonDraftNote = 'non-draft row correctly hides delete';
        }
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-07', 'TC-07-draft-actions'), fullPage: true });
        return `Draft ${draftNo} shows Edit+Delete; ${nonDraftNote}`;
      },
    );
  });

  // ---------- TC-DASH-08 (delete functionality, SAFE) ----------
  test('TC-DASH-08 | Delete functionality for a draft (confirmation)', async ({ page }) => {
    const dash = new InitiatorDashboardPage(page);
    await dash.goto();
    const allowRealDelete = (process.env.ALLOW_DELETE ?? '').toLowerCase() === 'true';
    await record(
      {
        id: 'TC-DASH-08',
        title: `Delete functionality for a draft ${allowRealDelete ? '(REAL delete)' : '(confirmation only, cancelled)'}`,
        expected: allowRealDelete
          ? 'Draft is deleted and disappears from the list'
          : 'Delete opens a confirmation; cancelled to preserve data',
      },
      async () => {
        const draft = dash.firstDraftRow();
        const draftNo = await dash.requestNoOf(draft);
        await dash.rowHasDelete(draft).click();

        // Wait for the "Excluir Solicitação" confirmation dialog to appear.
        const dialogTitle = page.locator('text=/Excluir Solicita|Delete Request|Confirmar Exclus/i').first();
        const dialogVisible = await dialogTitle
          .waitFor({ state: 'visible', timeout: 6_000 })
          .then(() => true)
          .catch(() => false);
        await page.screenshot({ path: reporter.screenshotPath('TC-DASH-08', 'TC-08-delete-confirm'), fullPage: true });
        expect(dialogVisible, 'a delete confirmation dialog should appear').toBe(true);

        const confirmBtn = page
          .getByRole('button', { name: /^(Confirm|Confirmar|Excluir|Delete|Sim|Yes|OK)$/i })
          .first();
        const cancelBtn = page
          .getByRole('button', { name: /^(Cancel|Cancelar|N[ãa]o)$/i })
          .first();

        const confirmVisible = await confirmBtn.isVisible().catch(() => false);
        expect(confirmVisible, 'a confirm button should be present in the dialog').toBe(true);

        if (!allowRealDelete) {
          // Safe default: cancel so we don't destroy real data.
          if (await cancelBtn.isVisible().catch(() => false)) {
            await cancelBtn.click();
          } else {
            await page.keyboard.press('Escape');
          }
          await page.waitForTimeout(500);
          return `Delete confirmation appeared for ${draftNo}; CANCELLED (set ALLOW_DELETE=true to perform a real delete).`;
        }

        // Opted in: actually delete and verify the row is gone.
        await confirmBtn.click();
        await page.waitForTimeout(1500);
        await dash.goto();
        const stillThere = await dash.rowFor(draftNo).count();
        expect(stillThere, 'deleted draft should no longer appear').toBe(0);
        return `Draft ${draftNo} deleted; no longer in list.`;
      },
    );
  });
});
