import { registerLibraryScenario } from '../src/libraryScenario.js';

/**
 * Scenario 10 — Attribute Value Master (read-only, admin-created data).
 * Run independently: npx playwright test tests/scenario-10.spec.ts
 */
registerLibraryScenario({
  scenario: 'scenario-10',
  title: 'Scenario 10 — Attribute Value Master',
  url: '/app/initiator/attribute-value-master',
  idPrefix: 'TC-S10',
});
