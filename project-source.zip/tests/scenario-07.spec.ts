import { registerLibraryScenario } from '../src/libraryScenario.js';

/**
 * Scenario 7 — Noun Modifier Library (read-only, admin-created data).
 * Run independently: npx playwright test tests/scenario-07.spec.ts
 */
registerLibraryScenario({
  scenario: 'scenario-07',
  title: 'Scenario 7 — Noun Modifier Library',
  url: '/app/initiator/noun-modifier-library',
  idPrefix: 'TC-S7',
});
