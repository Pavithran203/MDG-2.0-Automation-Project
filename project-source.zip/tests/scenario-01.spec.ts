import { test, expect, type Page } from '@playwright/test';
import { ALL_ROLES } from '../src/roles.js';
import { LoginPage } from '../src/LoginPage.js';
import { ResultsReporter, type TestCaseResult } from '../src/resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

/**
 * Scenario 1 — Login smoke test: every role can log in successfully and lands
 * on its own dashboard.
 *
 * Results saved to: results/scenario-01/<timestamp>/report.md
 */
test.describe.serial('Scenario 1 — All-roles login smoke test', () => {
  let reporter: ResultsReporter;

  test.beforeAll(() => {
    reporter = new ResultsReporter({ scenario: 'scenario-01', title: 'Scenario 1 — All-Roles Login', baseUrl: BASE_URL });
    console.log(`\n[results] scenario-01 -> ${reporter.runDir}`);
  });
  test.afterAll(() => {
    console.log(`[results] scenario-01 saved -> ${reporter.finalize()}`);
  });

  async function record(page: Page, rec: Omit<TestCaseResult, 'status'>, body: () => Promise<string>): Promise<void> {
    const started = Date.now();
    const full: TestCaseResult = { status: 'failed', ...rec };
    try {
      full.actual = await body();
      full.status = 'passed';
    } catch (err) {
      full.actual = `Error: ${(err as Error).message}`;
      await page.screenshot({ path: reporter.screenshotPath(rec.id), fullPage: true }).catch(() => {});
      full.status = 'failed';
      throw err;
    } finally {
      full.durationMs = Date.now() - started;
      reporter.add(full);
    }
  }

  let idx = 1;
  for (const creds of ALL_ROLES) {
    const id = `TC-S1-0${idx++}`;
    test(`${id} | ${creds.label} can log in`, async ({ page }) => {
      const loginPage = new LoginPage(page);
      await record(
        page,
        { id, title: `${creds.label} can log in`, input: creds.username, expected: `Logs in and lands on the ${creds.label} dashboard` },
        async () => {
          await loginPage.login(creds);
          await loginPage.assertLoggedIn(creds);
          const landingUrl = page.url();
          expect(landingUrl, `${creds.label} should reach an /app route`).toContain('/app');
          return `${creds.label} logged in; landed at ${landingUrl}`;
        },
      );
    });
  }
});
