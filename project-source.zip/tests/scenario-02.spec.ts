import { test, expect } from '@playwright/test';
import { ROLES } from '../src/roles.js';
import { LoginPage } from '../src/LoginPage.js';
import { ResultsReporter, type TestCaseResult } from '../src/resultsReporter.js';
import { BASE_URL } from '../playwright.config.js';

/**
 * Login scenario suite for the INITIATOR flow.
 *
 * Primary scenario under test:
 *   - Active user   -> logs in successfully
 *   - Inactive user -> login blocked, validation message shown
 *
 * Plus standard negative cases that any login test process should include.
 *
 * Results are saved to: results/initiator/<YYYY-MM-DD_HH-mm-ss>/
 */
test.describe.serial('Login scenarios (Initiator)', () => {
  let reporter: ResultsReporter;

  test.beforeAll(() => {
    reporter = new ResultsReporter({
      scenario: 'scenario-02',
      title: 'Scenario 2 — Initiator Login (active/inactive)',
      baseUrl: BASE_URL,
    });
    console.log(`\n[results] saving this run to: ${reporter.runDir}\n`);
  });

  test.afterAll(() => {
    const dir = reporter.finalize();
    console.log(`\n[results] run saved -> ${dir}\n`);
  });

  // ---------- TC-LOGIN-01: Active user, valid credentials ----------
  test('TC-LOGIN-01 | Active user logs in successfully', async ({ page }) => {
    const started = Date.now();
    const rec: TestCaseResult = {
      id: 'TC-LOGIN-01',
      title: 'Active user logs in successfully',
      input: `${ROLES.initiator.username} / valid password`,
      expected: 'Logs in; lands on /app/initiator/dashboard',
      status: 'failed',
    };
    try {
      const login = new LoginPage(page);
      await login.login(ROLES.initiator);
      await page.screenshot({ path: reporter.screenshotPath('TC-LOGIN-01', 'TC-01-active-login'), fullPage: true });

      expect(login.isOnLoginPage(), 'active user should leave the /login page').toBe(false);
      expect(page.url()).toContain('/app/initiator/dashboard');

      rec.actual = `Logged in; reached ${page.url()}`;
      rec.status = 'passed';
    } catch (err) {
      rec.actual = `Error: ${(err as Error).message}`;
      throw err;
    } finally {
      rec.durationMs = Date.now() - started;
      reporter.add(rec);
    }
  });

  // ---------- TC-LOGIN-02: Inactive user, valid credentials ----------
  test('TC-LOGIN-02 | Inactive user is blocked with a validation message', async ({ page }) => {
    const started = Date.now();
    const user = process.env.INACTIVE_USERNAME ?? '';
    const pass = process.env.INACTIVE_PASSWORD ?? '';
    const configured = user.length > 0 && pass.length > 0;

    const rec: TestCaseResult = {
      id: 'TC-LOGIN-02',
      title: 'Inactive user is blocked with a validation message',
      input: configured ? `${user} / valid password` : '(inactive account — not provided)',
      expected: 'Login blocked; validation message shown',
      status: configured ? 'failed' : 'blocked',
    };

    if (!configured) {
      rec.actual = 'Not executed — no inactive account configured (set INACTIVE_USERNAME/INACTIVE_PASSWORD in .env)';
      reporter.add(rec);
      test.skip(true, 'No inactive account configured.');
      return;
    }

    try {
      const login = new LoginPage(page);
      await login.loginWith(user, pass);
      await page.screenshot({ path: reporter.screenshotPath('TC-LOGIN-02', 'TC-02-inactive-login'), fullPage: true });

      expect(login.isOnLoginPage(), 'inactive user must stay on the /login page').toBe(true);
      const message = await login.getValidationMessage();
      console.log('[TC-LOGIN-02] inactive-user message:', message);
      expect(message, 'inactive user should see a validation message').not.toBeNull();

      rec.actual = `Stayed on /login; message: "${message}"`;
      rec.message = message;
      rec.status = 'passed';
    } catch (err) {
      rec.actual = `Error: ${(err as Error).message}`;
      throw err;
    } finally {
      rec.durationMs = Date.now() - started;
      reporter.add(rec);
    }
  });

  // ---------- TC-LOGIN-03: Valid user, wrong password ----------
  test('TC-LOGIN-03 | Valid user with wrong password is rejected', async ({ page }) => {
    const started = Date.now();
    const rec: TestCaseResult = {
      id: 'TC-LOGIN-03',
      title: 'Valid user with wrong password is rejected',
      input: `${ROLES.initiator.username} / wrong password`,
      expected: 'Rejected; message shown; stays on /login',
      status: 'failed',
    };
    try {
      const login = new LoginPage(page);
      await login.loginWith(ROLES.initiator.username, 'definitely-wrong-password');
      await page.screenshot({ path: reporter.screenshotPath('TC-LOGIN-03', 'TC-03-wrong-password'), fullPage: true });

      expect(login.isOnLoginPage(), 'wrong password should keep user on /login').toBe(true);
      const message = await login.getValidationMessage();
      console.log('[TC-LOGIN-03] wrong-password message:', message);
      expect(message, 'a validation message should be shown').not.toBeNull();

      rec.actual = `Stayed on /login; message: "${message}"`;
      rec.message = message;
      rec.status = 'passed';
    } catch (err) {
      rec.actual = `Error: ${(err as Error).message}`;
      throw err;
    } finally {
      rec.durationMs = Date.now() - started;
      reporter.add(rec);
    }
  });

  // ---------- TC-LOGIN-04: Non-existent user ----------
  test('TC-LOGIN-04 | Non-existent user is rejected', async ({ page }) => {
    const started = Date.now();
    const rec: TestCaseResult = {
      id: 'TC-LOGIN-04',
      title: 'Non-existent user is rejected',
      input: 'no-such-user-xyz@example.com / whatever123',
      expected: 'Rejected; message shown; stays on /login',
      status: 'failed',
    };
    try {
      const login = new LoginPage(page);
      await login.loginWith('no-such-user-xyz@example.com', 'whatever123');
      await page.screenshot({ path: reporter.screenshotPath('TC-LOGIN-04', 'TC-04-nonexistent-user'), fullPage: true });

      expect(login.isOnLoginPage(), 'unknown user should stay on /login').toBe(true);
      const message = await login.getValidationMessage();
      console.log('[TC-LOGIN-04] non-existent-user message:', message);
      expect(message, 'a validation message should be shown').not.toBeNull();

      rec.actual = `Stayed on /login; message: "${message}"`;
      rec.message = message;
      rec.status = 'passed';
    } catch (err) {
      rec.actual = `Error: ${(err as Error).message}`;
      throw err;
    } finally {
      rec.durationMs = Date.now() - started;
      reporter.add(rec);
    }
  });

  // ---------- TC-LOGIN-05: Empty fields ----------
  test('TC-LOGIN-05 | Empty fields block submission', async ({ page }) => {
    const started = Date.now();
    const rec: TestCaseResult = {
      id: 'TC-LOGIN-05',
      title: 'Empty fields block submission',
      input: '(blank) / (blank)',
      expected: 'Submission blocked; validation shown',
      status: 'failed',
    };
    try {
      const login = new LoginPage(page);
      await login.loginWith('', '');
      await page.screenshot({ path: reporter.screenshotPath('TC-LOGIN-05', 'TC-05-empty-fields'), fullPage: true });

      expect(login.isOnLoginPage(), 'empty submit should not log in').toBe(true);

      const userInvalid = await login.isFieldInvalid('username');
      const passInvalid = await login.isFieldInvalid('password');
      const message = await login.getValidationMessage();
      console.log('[TC-LOGIN-05] userInvalid=%s passInvalid=%s message=%s', userInvalid, passInvalid, message);

      expect(
        userInvalid || passInvalid || message !== null,
        'empty fields should trigger validation (native or custom message)',
      ).toBe(true);

      rec.actual = `Stayed on /login; message: "${message ?? '(native field validation)'}"`;
      rec.message = message;
      rec.status = 'passed';
    } catch (err) {
      rec.actual = `Error: ${(err as Error).message}`;
      throw err;
    } finally {
      rec.durationMs = Date.now() - started;
      reporter.add(rec);
    }
  });
});
