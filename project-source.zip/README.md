# MDG 2.0 Automation

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.


End-to-end UI automation for the MDG 2.0 web application, built with
[Playwright](https://playwright.dev/) + TypeScript.

## What's here so far

- Login automation for all five roles: **Initiator, Validator, Reviewer, Cataloguer, QC**.
- A discovery helper that dumps the real login-page structure so selectors can be tightened.
- Screenshots / video / traces captured automatically on failure for easy debugging.

The role-specific business flows (create request, validate, review, catalogue, QC)
are **not implemented yet** — they'll be added once each flow is described.

## Prerequisites

- [Node.js](https://nodejs.org/) 18 or newer.

## Setup

```bash
# 1. Install dependencies

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm install

# 2. Install the Playwright browsers

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npx playwright install

# 3. Create your .env from the template and fill in credentials

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

#    the real credentials are not included in this repository

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

cp .env.example .env
```

## Running

```bash
# Run all tests (headless)

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm test

# Run just the login smoke tests

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm run test:login

# Watch it happen in a real browser

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm run test:headed

# Interactive UI mode (great for debugging)

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm run test:ui

# Open the HTML report after a run

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npm run report
```

## Discovering the real page structure

If the login selectors need adjusting, run the discovery helper to see exactly
what the page contains:

## Scenarios — one file each, runnable independently

Each scenario lives in its own `tests/scenario-NN.spec.ts` and writes results to
`results/scenario-NN/<timestamp>/report.md`.

| Scenario | File | npm shortcut | Area |
|----------|------|--------------|------|
| 1  | `tests/scenario-01.spec.ts` | `npm run scenario-01` | All-roles login smoke (5 roles) |
| 2  | `tests/scenario-02.spec.ts` | `npm run scenario-02` | Initiator login (active/inactive + negatives) |
| 3  | `tests/scenario-03.spec.ts` | `npm run scenario-03` | Initiator Dashboard |
| 4  | `tests/scenario-04.spec.ts` | `npm run scenario-04` | Amend Request (real submit → validator) |
| 5  | `tests/scenario-05.spec.ts` | `npm run scenario-05` | Material Search |
| 6  | `tests/scenario-06.spec.ts` | `npm run scenario-06` | Master LOV Data |
| 7  | `tests/scenario-07.spec.ts` | `npm run scenario-07` | Noun Modifier Library (read-only) |
| 8  | `tests/scenario-08.spec.ts` | `npm run scenario-08` | Attribute Name Library (read-only) |
| 9  | `tests/scenario-09.spec.ts` | `npm run scenario-09` | Template Library (read-only) |
| 10 | `tests/scenario-10.spec.ts` | `npm run scenario-10` | Attribute Value Master (read-only) |

Run a single scenario by name:

```bash
npm run scenario-04
# or

> Full source tree is included in project-source.zip at the repository root. Unpack it to restore the directories and files summarized below.

npx playwright test tests/scenario-04.spec.ts
```

Run everything:

```bash
npm test
```

## Recording new flows (codegen)

The fastest way to capture a role's business flow is Playwright's recorder:

```bash
npm run codegen
```

## Project layout

```
.
├── src/
│   ├── roles.ts              # Role definitions + credentials from .env
│   ├── LoginPage.ts          # Login Page Object
│   ├── InitiatorDashboardPage.ts
│   ├── MaterialSearchPage.ts
│   ├── AmendRequestPage.ts
│   ├── LibraryPage.ts        # Shared read-only library page object
│   ├── libraryScenario.ts    # Shared suite for scenarios 7-10
│   └── resultsReporter.ts    # Writes results/scenario-NN/<timestamp>/report.md
├── tests/
│   └── scenario-01.spec.ts … scenario-10.spec.ts   # one file per scenario
├── results/                  # per-scenario, timestamped reports
├── .env                      # Real credentials (git-ignored)
├── .env.example              # Template
└── playwright.config.ts
```

## Security note

The `.env` file holds real credentials and is git-ignored — it must never be
committed. Since these credentials were shared in plain text, consider rotating
the passwords once automation work is complete.


