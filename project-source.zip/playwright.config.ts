import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';

// Load environment variables from .env
dotenv.config();

export const BASE_URL = process.env.BASE_URL ?? 'http://18.209.170.60:5506';

export default defineConfig({
  testDir: './tests',
  // Run tests in files in parallel
  fullyParallel: true,
  // Fail the build on CI if you accidentally left test.only in the source code.
  forbidOnly: !!process.env.CI,
  // Retry on CI only
  retries: process.env.CI ? 2 : 0,
  // Opt out of parallel tests on CI.
  workers: process.env.CI ? 1 : undefined,
  // Reporter to use.
  reporter: [
    ['list'],
    ['html', { open: 'never' }],
  ],
  // Shared settings for all the projects below.
  use: {
    baseURL: BASE_URL,
    // Collect trace, screenshot and video on failure for debugging.
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    // The app is served over plain HTTP on an IP, so ignore cert issues.
    ignoreHTTPSErrors: true,
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
    // HEADED mode: set HEADED=true to watch the browser (see the DOM / clicks live).
    // SLOWMO=<ms> adds a delay between actions so each step is easy to follow.
    headless: (process.env.HEADED ?? '').toLowerCase() !== 'true',
    launchOptions: {
      slowMo: process.env.SLOWMO ? Number(process.env.SLOWMO) : 0,
    },
  },
  timeout: 60_000,
  expect: {
    timeout: 10_000,
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
